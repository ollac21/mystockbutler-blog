## Executive summary

### What the business is

Tesla sells electric vehicles to households and commercial customers, and batteries, solar systems and energy software to homeowners, utilities and project developers. In 2025 it generated $94,827 million of revenue, delivered 1,636,129 vehicles and reported 1,553 Tesla locations. A dollar comes from an outright, financed or leased vehicle, an energy project, or a charging, service or software payment. Tesla also receives payments from automakers buying regulatory credits, certificates used to meet emissions or efficiency rules.

- Vehicle buyers pay outright, through financing or by lease; leasing leaves Tesla exposed to resale value. In 2025, deliveries were 1,636,129.
- FSD is driver-assistance software that still requires supervision. Tesla charges $99 a month in the U.S.; its 1.48 million active count combines subscribers and upfront buyers.
- Automotive margin excluding regulatory credits was 15.4% in 2025. Credits have little additional cost, but depend on regulation and other automakers’ needs.
- Energy gross margin was 29.8% in 2025, but the energy segment combines storage, solar and related activities, obscuring each project’s economics.

### The challenges

- **Vehicle pricing and profit per car.** Automotive margin excluding credits was 15.4% in 2024 and 2025. It was 16.3% in Q2 2026 as temporary benefits disappeared. Discounts and financing support can erase profit even when deliveries recover.

- **Factory and battery throughput.** Tesla produced more vehicles than it delivered in 2025, and inventory days rose to 15. Battery-pack capacity—the number of assembled battery units factories can supply—was a near-term limit. Announced capacity must become saleable output.

- **Autonomy becoming a paid business.** Tesla’s 1.48 million active FSD count includes upfront purchases and monthly subscriptions. Nevada approved ten vehicles rather than the 5,000 requested. Recurring revenue means payments that repeat; adoption and technical progress do not establish it or profitable rides at scale.

- **Energy project economics.** Energy gross margin reached 29.8% in 2025. Q2 2026 included an approximately $240 million adjustment for earlier vendor-cell problems. Deployments must produce durable project returns after warranty costs.

### The numbers

| US$ millions | Today (Oct 8, 2026) |
| --- | --- |
| Share price | 375.00 |
| Market value | 1,481,080.27275 |
| Enterprise value | 1,446,898.27275 |
| P/E, last 12 months | 347.2x |
| P/E, next 12 months | 164.0x |
| Free cash flow yield | 0.4% |
| Real free cash flow yield | 0.2% |
| Dividend yield | 0.0% |
| Buyback yield | 0.0% |

Revenue fell 2.9% in 2025, while net cash reached $35,683 million. Operating margin fell from 16.8% in 2022 to 4.6% in 2025. At $375.00, trailing P/E was 347.2x, leaving the share price dependent on future earnings.

**How it earns, and what can hurt it (US$ millions)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Revenue | 94,827 | 97,690 | 96,773 | 81,462 | 53,823 |
| Revenue growth | -2.9% | 0.9% | 18.8% | 51.4% | 70.7% |
| Operating margin | 4.6% | 7.2% | 9.2% | 16.8% | 12.1% |
| Real free cash flow, % of revenue | 3.6% | 1.6% | 2.6% | 7.4% | 5.3% |
| **= Net cash** | 35,683 | 28,350 | 23,864 | 19,086 | 10,873 |

**What one share gets (US$ per share)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| EPS, diluted | 1.08 | 2.04 | 4.30 | 3.62 | 1.63 |
| Real free cash flow per share | 0.96 | 0.45 | 0.73 | 1.72 | 0.85 |
| FCF per share — the company's own count | 1.76 | 1.02 | 1.25 | 2.18 | 1.47 |
| Free cash flow per share | 1.76 | 1.02 | 1.25 | 2.17 | 1.47 |
| − Paid to minority owners, per share | 0.02 | 0.03 | 0.04 | 0.05 | 0.05 |
| − Dividends paid, per share | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| − Share buybacks, per share | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| **= FCF not paid out, per share** | 1.74 | 0.99 | 1.21 | 2.13 | 1.42 |
| Stock pay per share | 0.80 | 0.57 | 0.52 | 0.45 | 0.63 |
| Book value per share | 21.90 | 22.67 | 19.67 | 14.13 | 9.74 |
| Diluted shares (average of the year), change | 0.9% | 0.4% | 0.3% | 2.6% | 4.2% |

### The verdict

Tesla’s October 2029 price could range from a deep loss to a major gain; the outcome hinges on vehicle economics, storage growth and paid software becoming material. Management plans more than $25 billion of 2026 capital expenditure, with Semi, Megapack 3—a large battery system for utility and commercial sites—and initial Optimus production scheduled for 2026. Starts do not establish profitable output.

The weighted price is $284.52 in October 2027 and $336.44 in October 2029. That implies a 24% loss including dividends by October 2027 and a 10% loss by October 2029. The bear case is $63.43 and the base case is $312.09. The bull case is $971.74; the probabilities are 30% bear, 55% base and 15% bull. Tesla’s real free cash flow was 3.6% of revenue, while stock pay was $0.80 per share in 2025.

The near-term test is October 21, 2026, when Tesla plans to report Q3 results after 486,532 deliveries. Through 2027, higher saleable output without equivalent discounting, sustained energy profit and growing paid software revenue support the bull case; underused factories, weaker margins or cash burn support the bear case. Tesla must turn future promises into durable per-share cash earnings.

## 5. The numbers

Tesla is not one business but a set of businesses whose accounts reveal different kinds of growth, profit and risk. Read like a specialist reads them, the numbers say that sales can recover before earning power, cash and returns on new investment do.

### 5.1 — Growth

Tesla became much larger, but its growth has stopped. Revenue rose strongly over five years, then declined 2.9% in 2025, while vehicle deliveries fell after peaking in 2023.

The businesses underneath the total moved differently. Automotive revenue contracted, while energy generation and storage revenue rose 27%. Storage deployments grew 49%, much faster than energy revenue, because deployment measures battery capacity delivered or installed, while revenue measures what Tesla records for selling, leasing or financing it. A larger warehouse does not necessarily contain more valuable goods: Megapack prices, project timing and mix matter.

The Q2 2026 AI-hardware acquisition shows the same discipline. It demonstrates investment in technology, not disclosed customer revenue or manufacturing capacity. Growth therefore has to be tested by business, price and economics before it is called progress.

The five-year table puts revenue, profit, margins, earnings per share and dividends in one view.

**Results (US$ millions)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Revenue | 94,827 | 97,690 | 96,773 | 81,462 | 53,823 |
| Revenue growth (calculated) | -2.9% | 0.9% | 18.8% | 51.4% | 70.7% |
| Gross profit | 17,094 | 17,450 | 17,660 | 20,853 | 13,606 |
| Gross margin (calculated) | 18.0% | 17.9% | 18.2% | 25.6% | 25.3% |
| Operating income | 4,355 | 7,076 | 8,891 | 13,656 | 6,523 |
| Net income | 3,794 | 7,091 | 14,997 | 12,556 | 5,519 |
| Net margin (calculated) | 4.0% | 7.3% | 15.5% | 15.4% | 10.3% |
| EPS, diluted | 1.08 | 2.04 | 4.30 | 3.62 | 1.63 |
| Dividend per share | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

The company’s own operating measures show whether reported growth is reaching vehicles, storage and infrastructure.

**The company's own measures**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Total production (vehicles) | 1,654,667 | 1,773,443 | 1,845,985 | 1,369,611 | 930,422 |
| Total deliveries (vehicles) | 1,636,129 | 1,789,226 | 1,808,581 | 1,313,851 | 936,222 |
| Active FSD Subscriptions (mil) | 1.1 | 0.8 | 0.6 | 0.5 | 0.4 |
| Global vehicle inventory (days of supply) | 15 | 13 | 16 | 16 | 6 |
| Storage deployed (GWh) | 46.7 | 31.4 | 14.7 | 6.5 | 4.0 |
| Tesla locations | 1,553 | 1,359 | 1,208 | 963 | 644 |
| Supercharger stations | 8,182 | 6,975 | 5,952 | 4,678 | 3,476 |
| Supercharger connectors | 77,682 | 65,495 | 54,892 | 42,419 | 31,498 |

The next question is whether this larger but slower-growing business still earns enough from each sale.

### 5.2 — Profit

Tesla’s profitability weakened much more than its sales. Gross margin fell from 25.6% in 2022 to 18.0% in 2025, while operating income fell to $4,355 million.

Operating income is what remains after direct production costs and expenses such as research and administration. That fall means Tesla now keeps much less from each dollar of revenue.

Reported net income in 2023 also received a major tax benefit. Tesla released a valuation allowance against deferred-tax assets, which are expected future tax savings. The release records an accounting benefit when future use becomes more likely; it does not mean customers paid more. Removing the main release leaves a much lower profit.

Other charges need the same care. Restructuring and inventory write-downs affect earnings, but inventory write-downs recur, so treating them as exceptional would flatter the business. Crypto revaluations, SpaceX gains and small tax adjustments belong in separate compartments. Research and development rose 41%; removing it would remove the cost of trying to build future products.

The company’s adjusted measures and tax rates show how reported earnings change under Tesla’s own definitions.

**The company's own adjusted measures, and tax (US$ millions)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Adjusted EBITDA (company's measure) | 14,596 | 16,056 | 16,631 | 19,390 | 11,722 |
| Adjusted net income (company's measure) | 5,858 | 7,960 | 10,882 | 14,276 | 7,719 |
| Adjusted EPS (company's measure) | 1.66 | 2.29 | 3.12 | 4.12 | 2.28 |
| Effective tax rate (calculated) | 27.0% | 20.4% | -50.1% | 8.3% | 11.0% |

The specialist starts with operating profit, then adjusts once, without pretending recurring costs have disappeared.

### 5.3 — Cash

Tesla’s 2025 free-cash-flow improvement came mainly from spending less on assets. Profit and cash differ because inventory, customer payments and supplier bills arrive on different schedules.

Operating cash was slightly lower, but capital spending fell from the previous year, so free cash flow rose to $6,220 million. Free cash flow is operating cash left after capital spending. The improvement therefore says more about investment timing than about stronger operating cash generation.

Stock compensation creates another gap. Tesla adds this noncash expense back because shares, rather than cash, go to employees. But shareholders still bear an economic cost through dilution. Deducting $2,825 million from reported free cash flow gives a stricter view, without making Tesla’s official measure mathematically wrong.

Tesla’s planned capital spending of more than $25 billion would put heavy pressure on cash if operating cash stayed near 2025 levels. The next test is whether new assets create enough saleable output and recurring revenue.

The table separates operating cash, investment, stock pay and the company’s own free-cash-flow definition.

**Follow the money: real free cash flow (US$ millions)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Cash from operations | 14,747 | 14,923 | 13,256 | 14,724 | 11,497 |
| − Capital spending | 8,527 | 11,342 | 8,899 | 7,172 | 6,514 |
| **= Free cash flow** | 6,220 | 3,581 | 4,357 | 7,552 | 4,983 |
| − Stock pay | 2,825 | 1,999 | 1,812 | 1,560 | 2,121 |
| **= Real free cash flow** | 3,395 | 1,582 | 2,545 | 5,992 | 2,862 |
| Free cash flow — the company's own count | 6,220 | 3,581 | 4,357 | 7,561 | 4,983 |
| What its own count adds back | 0 | 0 | 0 | 9 | 0 |
| What its own count also takes out | 0 | 0 | 0 | | 0 |
| Free cash flow, % of revenue | 6.6% | 3.7% | 4.5% | 9.3% | 9.3% |
| Real free cash flow, % of revenue | 3.6% | 1.6% | 2.6% | 7.4% | 5.3% |

Cash must then be set against the assets and obligations on Tesla’s balance sheet.

### 5.4 — Balance sheet and debt

Tesla has substantial liquidity, but its balance sheet does not make investment risk disappear. Cash and short-term investments totalled $44,059 million at December 2025, far more than total debt.

Current assets exceeded current liabilities by $36,928 million. That gives Tesla room to pay near-term bills, although inventory and receivables are less liquid than cash. Other obligations matter too: leases, supplier bills, warranties and deferred revenue all represent claims on future resources.

Most of Tesla’s June 2026 debt was non-recourse, meaning lenders could generally claim only the assets of the borrowing subsidiary. That limits legal reach but not economic risk. The China working-capital facility was $5.888 billion and depended on refinancing. Tesla classified it as long-term because it expected to refinance it, so today’s liquidity does not remove tomorrow’s refinancing risk.

The balance-sheet table shows liquidity, liabilities, equity and the calculated measures of short-term strength.

**Balance sheet (US$ millions)**

| Row | 2025 | 2024 | 2023 | 2022 | 2021 |
| --- | --- | --- | --- | --- | --- |
| Cash | 16,513 | 16,139 | 16,398 | 16,253 | 17,576 |
| Short-term investments | 27,546 | 20,424 | 12,696 | 5,932 | 131 |
| Total current assets | 68,642 | 58,360 | 49,616 | 40,917 | 27,100 |
| Total assets | 137,806 | 122,070 | 106,618 | 82,338 | 62,131 |
| Total current liabilities | 31,714 | 28,821 | 28,748 | 26,709 | 19,705 |
| Total liabilities | 54,941 | 48,390 | 43,009 | 36,440 | 30,548 |
| Total debt (calculated) | 8,376 | 8,213 | 5,230 | 3,099 | 6,834 |
| Lease liabilities | 6,566 | 5,745 | 4,916 | 3,703 | 3,531 |
| Shareholders' equity | 82,137 | 72,913 | 62,634 | 44,704 | 30,189 |
| Current assets over current liabilities (calculated) | 36,928 | 29,539 | 20,868 | 14,208 | 7,395 |
| Current ratio (calculated) | 2.2x | 2.0x | 1.7x | 1.5x | 1.4x |
| Book value per share (calculated) | 21.90 | 22.67 | 19.67 | 14.13 | 9.74 |

The latest quarter shows whether that financial strength is being converted into better operating results.

### 5.5 — The latest quarter

Q2 2026 showed a sales recovery, not yet an earnings recovery. Revenue rose 25.5% year over year, and vehicle deliveries reached 480,126.

Gross margin slipped to 16.8%, while operating income fell to $398 million. Gross margin is the share of revenue left after direct costs; operating income also subtracts ongoing expenses. Tesla sold more while retaining less operating profit.

Temporary benefits explain part of the deterioration. Earlier warranty and tariff benefits did not repeat, while energy recorded a warranty adjustment involving earlier deployments. Reported net income included a $763 million SpaceX remeasurement gain and a $274 million tax benefit. Removing those two items leaves only a small amount beside operating profit.

Cash from operations improved, but capital spending reached $5,796 million, leaving negative free cash flow. A specialist would call this a turn in sales and wait for several quarters of stronger margins and cash before calling it a turn in the business.

The quarterly table places sales, margins, earnings and cash generation beside one another.

**The last eight quarters (US$ millions)**

| Row | Jun 2026 | Mar 2026 | Dec 2025 | Sep 2025 | Jun 2025 | Mar 2025 | Dec 2024 | Sep 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 28,236 | 22,387 | 24,901 | 28,095 | 22,496 | 19,335 | 25,707 | 25,182 |
| Gross margin | 16.8% | 21.1% | 20.1% | 18.0% | 17.2% | 16.3% | 16.3% | 19.8% |
| Operating income | 398 | 941 | 1,409 | 1,624 | 923 | 399 | 1,583 | 2,717 |
| Net income | 1,114 | 477 | 840 | 1,373 | 1,172 | 409 | 2,128 | 2,173 |
| EPS, diluted | 0.32 | 0.13 | 0.24 | 0.39 | 0.33 | 0.12 | 0.60 | 0.62 |
| Cash from operations | 4,697 | 3,937 | 3,813 | 6,238 | 2,540 | 2,156 | 4,814 | 6,255 |
| − Capital spending | 5,796 | 2,493 | 2,393 | 2,248 | 2,394 | 1,492 | 2,780 | 3,513 |
| **= Free cash flow** | -1,099 | 1,444 | 1,420 | 3,990 | 146 | 664 | 2,034 | 2,742 |

The vehicle figures need one further separation: volume is not the same as price or profit per vehicle.

### 5.6 — Vehicle pricing, mix and profit per vehicle

Tesla’s vehicle economics depend on what each sale earns after discounts, financing support and costs. Average selling price means average vehicle-sales revenue per vehicle sold, so it should use vehicle revenue rather than total company revenue.

A rough division of vehicle revenue by deliveries can screen the trend, but it mixes accounting timing and product types. Automotive gross margin excluding regulatory credits held at 15.4% in both 2024 and 2025. That stability suggests cost reductions absorbed pricing pressure, but it does not reveal the economics of each model.

Mix means the combination of models and markets sold. More lower-priced versions can reduce average selling price without a list-price cut. Batteries, factories, freight, tariffs and exchange rates can also change cost. Q2 automotive margin excluding credits fell to 16.3% as temporary benefits disappeared.

Residual value—the expected resale value after use—also affects leasing economics. The optimist wants stable transaction prices and falling costs; the specialist checks discounts, financing support and used-car values together.

### 5.7 — Factory utilization, ramp execution and cost per vehicle

Tesla’s factories create value only when enough saleable vehicles absorb their fixed costs. Buildings, machinery and staff cost money before the next vehicle leaves the line, so low utilization raises the cost of each one.

A ramp brings a new line or model toward dependable volume. Training, stoppages and rework can make early production expensive. Tesla produced more vehicles than it delivered in 2025, while inventory days rose to 15. That gap can reflect shipping timing, but it remains an important inventory signal.

Installed capacity is not the same as practical output. Batteries, equipment uptime, suppliers and model changes can constrain a nominal line; Tesla identified battery-pack capacity as a near-term constraint. Average automotive cost per vehicle is useful, but it blends models and factories and still includes the economic burden of depreciation.

The question is whether output, quality and cost improve together before spare capacity becomes a liability.

### 5.8 — Energy-storage project economics and deployment pace

Energy storage is becoming a meaningful second business, but deployment growth alone does not prove durable profit. A battery can shift electricity from cheap periods to expensive ones and provide grid-stability services, which gives the customer value beyond the hardware.

Tesla’s storage revenue grew more slowly than deployments because prices, project mix and delivery timing matter. Deployment includes equipment sold when delivered, so a reported installation need not mean the whole project is operating. The energy segment’s gross margin rose to 29.8% in 2025, supporting its importance, but that segment also includes solar and related activities.

Warranty costs can surface later: Q2 2026 included an approximately $240 million adjustment involving vendor cells in earlier projects. Tesla’s software and revenue-guarantee arrangements also connect its returns to the customer’s project economics. Volume becomes durable growth only when prices, reliability and customer returns remain healthy.

### 5.9 — Paid software adoption and recognized software revenue

Tesla’s FSD count measures adoption, not monthly recurring revenue. A customer may buy access upfront or pay monthly, while a free trial is excluded; those forms of use do not create the same cash or accounting pattern.

The reported count therefore cannot be multiplied by the monthly price to estimate current revenue. An upfront purchase resembles a long-term membership: Tesla receives money earlier but may recognize it over the period in which it still owes software access or updates.

Deferred revenue is money collected for obligations not yet fulfilled. Tesla reported $4.05 billion covering FSD, connectivity, free Supercharging and software updates, so it is not an FSD-only backlog. The specialist looks for retention, revenue per payer and separately identified software revenue.

Software adoption matters, but recognized revenue shows what the adoption is worth economically.

### 5.10 — Charging-network utilization

Tesla’s charging network creates value only when enough drivers use each installation to cover electricity, operating and capital costs. Stations are locations; connectors are the individual charging points, so network counts show reach but not utilization.

Tesla measures site utilization through charging sessions per stall per day. Busy sites can spread demand charges—the electricity bill’s peak-power component—across more customer payments and more energy sold. Quiet sites cannot.

A specialist therefore follows sessions and kilowatt-hours per connector, then compares them with electricity, maintenance, rent and installed capital. Tesla reports paid charging inside a broader services category, so that category cannot reveal charging margin by itself. More connectors help only when traffic and contribution profit rise with them.

### 5.11 — Battery warranty and degradation indicators

Battery durability affects Tesla’s economics years after the original sale. Degradation is the gradual loss of capacity; it differs from a sudden component failure and from the contractual warranty floor.

Tesla’s warranties generally promise at least 70% capacity retention for specified periods. Its $8,607 million warranty reserve is an estimate across vehicles, energy products and components, not a battery-repair bill. Tesla records expected costs when it sells products and revises the estimate as evidence changes.

Independent evidence is useful only when it matches model, chemistry, age, mileage and climate. A young fleet may not reveal later failures, while connected-data samples may not represent every owner. Different chemistries trade range, cost and mineral use in different ways; none proves the whole economic case.

The specialist therefore watches battery-specific claims, manufacturing yield, repairability and degradation over time. That is where a recorded sale becomes a test of lifetime value.
